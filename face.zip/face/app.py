from flask import Flask, render_template, request, jsonify
import face_recognition
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if request.method == 'POST':
        image = request.files['image']
        known_image = face_recognition.load_image_file(os.path.join('static', 'known_face.jpg'))
        known_face_encoding = face_recognition.face_encodings(known_image)[0]
        unknown_image = face_recognition.load_image_file(image.filename)
        unknown_face_encodings = face_recognition.face_encodings(unknown_image)
        if unknown_face_encodings:
            unknown_face_encoding = unknown_face_encodings[0]
            results = face_recognition.compare_faces([known_face_encoding], unknown_face_encoding)
            if results[0] == True:
                return jsonify({'match': True})
            else:
                return jsonify({'match': False})
        else:
            return jsonify({'match': False})

if __name__ == '__main__':
    app.run(debug=True)
