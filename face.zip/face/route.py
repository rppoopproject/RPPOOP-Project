@app.route("/upload", methods=["POST"])
def upload():
    # Get the uploaded image from the request
    uploaded_image = request.files["image"]

    # Save the uploaded image to a temporary file
    temp_file = "temp_image.jpg"
    uploaded_image.save(temp_file)

    # Load the uploaded image and extract its features
    uploaded_face_image = face_recognition.load_image_file(temp_file)
    uploaded_face_encoding = face_recognition.face_encodings(uploaded_face_image)[0]

    # Compare the uploaded face with the known face
    match = face_recognition.compare_faces([known_face_encoding], uploaded_face_encoding)

    # Delete the temporary file
    os.remove(temp_file)

    # Return the result as a JSON object
    return {"match": match[0]}
