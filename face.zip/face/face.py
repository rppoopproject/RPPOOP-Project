import cv2
import face_recognition

# Load the known face image and extract its features
known_image = face_recognition.load_image_file("known_face.jpg")
known_face_encoding = face_recognition.face_encodings(known_image)[0]

# Initialize the video capture object
video_capture = cv2.VideoCapture(0)

while True:
    # Capture a frame from the video capture object
    ret, frame = video_capture.read()

    # Convert the frame to grayscale
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale frame
    face_locations = face_recognition.face_locations(gray_frame)

    # Loop through the detected faces
    for top, right, bottom, left in face_locations:
        # Extract the face image from the frame
        face_image = frame[top:bottom, left:right]

        # Extract features from the face image
        face_encoding = face_recognition.face_encodings(face_image)[0]

        # Compare the extracted features with the known face encoding
        match = face_recognition.compare_faces([known_face_encoding], face_encoding)

        # If the face matches the known face, draw a rectangle around it
        if match[0]:
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

    # Display the frame
    cv2.imshow("Video", frame)

    # Exit the loop if the 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

# Release the video capture object and close the window
video_capture.release()
cv2.destroyAllWindows()
